import { Component, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { ValidationService } from '../../services/validation.service';
import {ApiService} from '../../services/api.service';
import { NgxSpinnerService } from 'ngx-spinner'; 
import Swal from 'sweetalert2/dist/sweetalert2.js'

@Component({
  selector: 'app-resetpassword',
  templateUrl: './resetpassword.component.html',
  styleUrls: ['./resetpassword.component.css']
})
export class ResetpasswordComponent implements OnInit {

  constructor(private fb: FormBuilder, private api:ApiService,private router: Router, private loading: NgxSpinnerService) { }

  ngOnInit() {

  }
  resetpwdForm = this.fb.group({
    newpassword: [''],
    confirmpassword:['']
  });

  onSubmit()
  {
    console.warn(this.resetpwdForm.value);
    if(this.resetpwdForm.value.newpassword === this.resetpwdForm.value.confirmpassword){
      this.api.add_reset(this.resetpwdForm.value).subscribe(res =>{
        if(res.status){
          Swal.fire('Success..', 'Password has been succesfully changed', 'success'); 
           this.resetpwdForm.patchValue({newpassword:'',confirmpassword:''});
        }else{
          Swal('Oops...', 'Something went wrong!', 'error');
        }
      });
    }else{
      Swal.fire('Oops...', 'Something went wrong!', 'error');
      this.resetpwdForm.patchValue({newpassword:'',confirmpassword:''});
    }
  }

}
