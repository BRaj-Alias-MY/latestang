import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { EducationComponent } from '../education/education.component';
import { ExperienceComponent } from '../experience/experience.component';
import { HttpClient } from "@angular/common/http";
import Swal from "sweetalert2/dist/sweetalert2.js";
import { Router } from "@angular/router";
import { Profile } from "../userprofile2/profile";
@Component({
  selector: 'app-userprofile2',
  templateUrl: './userprofile2.component.html',
  styleUrls: ['./userprofile2.component.css']
})
export class Userprofile2Component implements OnInit {
  profileForm: FormGroup;
  userId = localStorage.getItem('userId');
  userprofile: Profile;
  email = localStorage.getItem('email');
  result: any;
  edu = [];
  exp = [];
  GET_EDU_URL = "http://localhost:3000/api/userprofile/getedu";
  GET_EXP_URL = "http://localhost:3000/api/userprofile/getexp";
  DELETE_EDU_URL = "http://localhost:3000/api/userprofile/deleteedu/";
  DELETE_EXP_URL = "http://localhost:3000/api/userprofile/deleteexp/";
  PROFILE_URL = "http://localhost:3000/api/userprofile/saveprofile2/";
  POST_FILE_URL = "http://localhost:3000/api/userprofile/upload/";
  GET_USER_URL = "http://localhost:3000/api/userprofile/getprofile/";
  constructor(private router: Router, private http: HttpClient, private dialog: MatDialog, private fb: FormBuilder) {
    this.userprofile = new Profile();

  }

  ngOnInit() {
    this.http.get<any[]>(this.GET_EDU_URL).subscribe(res => { this.edu = res; console.log(res) }, err => { console.log(err) });
    this.http.get<any[]>(this.GET_EXP_URL).subscribe(res => { this.exp = res; console.log(res) }, err => { console.log(err) });
    this.http.get<any>(this.GET_USER_URL + this.userId).subscribe(res => { this.userprofile = res[0]; console.log(this.userprofile) }, err => { console.log(err) });

    this.userId = localStorage.getItem('userId');
    this.email = localStorage.getItem('email');
    //alert(this.userId);
    this.profileForm = this.fb.group({
      about: [''],
      userId: [this.userId],
      adress: [''],
      pincode: [''],
      linkedinId: [''],
      resume: ['']

    })
  }
  onSubmit() {
    this.userprofile = this.profileForm.value;
    this.http.post<any>(this.PROFILE_URL, this.userprofile).subscribe(res => { this.result = 'Profile Updated Successfully!'; console.log(res) }, err => console.log(err));
    // this.http.post<any>(this.POST_FILE_URL,resume)
    //console.log(this.profileForm['resume']);

  }

  openDialog() {
    this.dialog.open(EducationComponent, {
      width: '90%',
      disableClose: true


    });



  }
  openDialog2() {
    this.dialog.open(ExperienceComponent, {
      width: '90%',
      disableClose: true

    });

  }
  deleteEdu(id, education) {
    //alert(id);
    return Swal.fire({
      title: "Are you sure?",
      text: "Do you want to delete it?",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, Delete it!",
      cancelButtonText: "No, keep it"
    }).then(result => {
      if (result.value) {
        this.http.get(this.DELETE_EDU_URL + id + '/' + education).subscribe(res => console.log(res), err => console.log(err));
        // return this.router.navigate(['/examboard2/userprofile2']);
        return window.location.href = "/examboard2/userprofile2";
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire("Cancelled", "Your imaginary data is safe :)", "error");
      }
    });
  }
  deleteExp(id, organizationName) {
    //  alert(id);
    return Swal.fire({
      title: "Are you sure?",
      text: "Do you want to delete it?",
      type: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, Delete it!",
      cancelButtonText: "No, keep it"
    }).then(result => {
      if (result.value) {
        this.http.get(this.DELETE_EXP_URL + id + '/' + organizationName).subscribe(res => console.log(res), err => console.log(err));
        return window.location.href = "/examboard2/userprofile2";
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire("Cancelled", "Your imaginary data is safe :)", "error");
      }
    });
  }


}
