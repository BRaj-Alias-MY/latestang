import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../app.service';
declare var $: any;
@Component({
  selector: 'app-review',
  templateUrl: './review.component.html',
  styleUrls: ['./review.component.css']
})
export class ReviewComponent implements OnInit {
  mydata = [];
  constructor(private service: AppService) { }
  reviewId = localStorage.getItem('vid');
  ngOnInit() {
    this.getReviews();

  }
  getReviews() {
    this.service.getReviews(this.reviewId).subscribe(resp => { console.log(resp); this.mydata = resp; }, err => console.log(err));
  }

}
