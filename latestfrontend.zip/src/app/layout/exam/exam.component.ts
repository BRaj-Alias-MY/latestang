import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AppService } from '../../app.service';
import { ApiService } from '../../services/api.service';
import { FormControl, FormGroup } from '@angular/forms';
@Component({
  selector: 'app-exam',
  templateUrl: './exam.component.html',
  styleUrls: ['./exam.component.css']
})
export class ExamComponent implements OnInit {

  constructor(private activatedRoute: ActivatedRoute, private router: Router, private service: AppService, private api: ApiService) { }
  interviews = [];
  profiledisplay: any;
  isDisplay = false;
  routeUrl: any;
  ngOnInit() {

    //refresh

    //refresh

    this.router.events.subscribe((event) => {
      this.routeUrl = this.router.url;

      if (this.routeUrl == '/examboard/mock') {
        this.isDisplay = true;

      }
      else {
        this.isDisplay = false;
      }

    });



    this.getInterview();
  }
  logout() {
    this.api.logout();
    this.router.navigate(['/login']);
  }

  getInterview() {
    let email = localStorage.getItem('email');
    //alert(this.email + this.domain + this.subdomain);
    this.service.getInterviews()
      .subscribe(resp => { this.interviews = resp; console.log(this.interviews) }, err => console.log(err));
  }
}
