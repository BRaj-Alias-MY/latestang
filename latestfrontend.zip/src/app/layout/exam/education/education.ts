export class Education {
    userProfileId: number;
    education: string;
    university: string;
    courseFrom: string;
    courseTo: string;
    specilization: string;
    grade: string;
}