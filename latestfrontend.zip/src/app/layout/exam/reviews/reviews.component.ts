import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';

import { ChartType } from 'chart.js';
import { AppService } from '../../../app.service';
import * as jspdf from 'jspdf';
import html2canvas from 'html2canvas';
@Component({
  selector: 'app-reviews',
  templateUrl: './reviews.component.html',
  styleUrls: ['./reviews.component.css']
})
export class ReviewsComponent implements OnInit {
  // PolarArea

  public polarAreaChartLabels: string[] = ['Download Sales', 'In-Store Sales', 'Mail Sales', 'Telesales'];
  public polarAreaChartData: any = [5, 6, 7, 8, 9, 10];
  public polarAreaLegend = true;
  reviewId = localStorage.getItem('vid');
  public polarAreaChartType: ChartType = 'polarArea';
  mydata = [];
  constructor(private service: AppService) { }

  ngOnInit() {
    this.getReviews();

  }
  getReviews() {
    this.service.getReviews(this.reviewId).subscribe(resp => { console.log(resp); this.mydata = resp; }, err => console.log(err));
  }

  public generatePDF() {
    var data = document.getElementById('contentToConvert');
    const doc = new jspdf();
    const content = document.getElementById('contentToConvert');
    html2canvas(content).then(canvas => {
      const imgData = canvas.toDataURL('image/png');
      // Few necessary setting options
      const imgWidth = 208;
      const pageHeight = 295;
      const imgHeight = canvas.height * imgWidth / canvas.width;
      const doc = new jspdf('p', 'mm');
      let heightLeft = imgHeight;
      let position = 0;
      const margins = {
        top: 80,
        bottom: 60,
        left: 40,
        width: 522
      };

      doc.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);

      heightLeft -= pageHeight;
      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        doc.addPage();
        heightLeft = 0;
        doc.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }
      // Generated PDF

      doc.save('Assessement' + '.pdf');
    });
  }


  // events
  public chartClicked({ event, active }: { event: MouseEvent, active: {}[] }): void {
    console.log(event, active);
  }

  public chartHovered({ event, active }: { event: MouseEvent, active: {}[] }): void {
    console.log(event, active);
  }

}
