import { Component, OnInit } from '@angular/core';
declare var $: any;
declare var window: any;
@Component({
  selector: 'app-speech',
  templateUrl: './speech.component.html',
  styleUrls: ['./speech.component.css']
})
export class SpeechComponent implements OnInit {
  message: any;
  constructor() { }

  ngOnInit() {
    $(document).ready(function () {

    });
  }

}
