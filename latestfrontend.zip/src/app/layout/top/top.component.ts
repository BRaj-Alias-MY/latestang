import { Component, OnInit } from '@angular/core';
import {ApiService} from '../../services/api.service';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';

 
@Component({
  selector: 'app-top',
  templateUrl: './top.component.html',
  styleUrls: ['./top.component.css']
})
export class TopComponent implements OnInit {

  constructor(private fb: FormBuilder, private api: ApiService, private route: Router) { }

  ngOnInit() {
  }
  logout(){
    this.api.logout();
    location.reload();
  }

}
